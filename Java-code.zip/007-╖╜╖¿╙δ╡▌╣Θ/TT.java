public class TT{

	public static void doSome(){
		System.out.println("do something!!!!");
	}
}