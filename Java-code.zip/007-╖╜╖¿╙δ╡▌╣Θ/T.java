public class T{
	public static void main(String[] args){
		// ����TT��doSome?
		TT.doSome();
	}
}

/*
class TT{

	public static void doSome(){
		System.out.println("do something!!!!");
	}
}
*/